@ECHO Off
BEN Cls LightGray / GrowFilledBox 5 3 76 23 White Blue 1
BEN Locate 1 5 / WriteC Yellow Blue MBFUTool~-~SELECT~DISK
BEN Locate 1 7 / WriteC Cyan LightBlue Use~arrow~keys~and~Enter
BEN Menu Select~target~USB~flash~drive: Disk~1~D:~14.65GB~General~UDisk - Cancel
If Errorlevel 2 Goto Cancel
If Errorlevel 1 Goto Sel1
Goto Cancel
:Sel1
ECHO SELECT 1> E:\REQUEST.TXT
Goto End
:Cancel
ECHO CANCEL> E:\REQUEST.TXT
:End
BEN CleanUp
exit
