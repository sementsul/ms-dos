@ECHO Off
BEN Cls LightGray / GrowFilledBox 5 3 76 23 White Blue 1
BEN Locate 1 5 / WriteC Yellow Blue MBFU~-~MS-DOS~IMAGE~TOOLS~~~DEMO
BEN Locate 1 8 / WriteC White Blue Write~MS-DOS~image~to~USB~flash
BEN Locate 1 9 / WriteC White Blue Create~MBFU~image~from~disk/floppy/USB
BEN Locate 1 10 / WriteC White Blue Clone~MS-DOS~disk/floppy/USB~to~USB
BEN Locate 1 11 / WriteC White Blue Edit~MS-DOS~image~with~DOS~commands
BEN Locate 1 12 / WriteC White Blue Exit
BEN Locate 1 21 / WriteC Yellow Blue Trial:~30~day(s)~left~-~boosty.to/mbfu
BEN Locate 1 22 / WriteC Cyan LightBlue Author:~Sementsul~Maxim
BEN Locate 1 23 / WriteC Cyan LightBlue Use~arrow~keys~and~Enter
BEN Menu MBFU~-~MS-DOS~image~tools: Write~image~to~USB Create~MBFU~image Clone~MS-DOS~media~to~USB Edit~MS-DOS~image - Exit
If Errorlevel 5 Goto Quit
If Errorlevel 4 Goto Edit
If Errorlevel 3 Goto Clone
If Errorlevel 2 Goto Create
If Errorlevel 1 Goto Write
Goto End

:Write
ECHO WRITE> E:\REQUEST.TXT
Goto End
:Create
ECHO CREATE> E:\REQUEST.TXT
Goto End
:Clone
ECHO CLONE> E:\REQUEST.TXT
Goto End
:Edit
ECHO EDIT> E:\REQUEST.TXT
Goto End
:Quit
ECHO QUIT> E:\REQUEST.TXT

:End
BEN CleanUp / Locate 1 25
exit
